

export interface AppStore{
    name?: string;
    description:string;
    id:number;
    business?:string;
    dashboard:boolean;
    createdby?:string;
    categories?:string;
   
}


