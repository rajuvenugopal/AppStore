package com.apps.AppStore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppStoreApplication.class, args);
	}
}
